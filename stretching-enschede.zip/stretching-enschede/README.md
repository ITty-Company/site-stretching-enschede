# Stretching Classes Enschede — website

Static site for Cloudflare Workers (assets only). Idea: «One band. Every Monday.» — one real-time 3D scene, «De Band»:
the pink fabric loop band from her avatar, built in code (fabric shell with canvas normals, inner layer, red seam,
woven label), in her studio (oak floor, pink mat, mirror wall with a live reflection, red velvet curtains).
Scrolling is the class: rest on the mat → two sock-feet pick it up (warm-up) → the band opens into its layers →
a twist into a figure eight → one line across the screen in front of a giant «18:00» → two simple steps →
spring release → an ∞ above the mat. Scrolling back rebuilds every frame exactly. Header timer runs 18:00 → Monday (без длительности).

## Structure
- `public/` — the whole site. EN: `index.html`, `classes.html`, `schedule.html`, `coach.html`, `register.html`, `404.html`;
  NL: `nl/index.html`, `nl/lessen.html`, `nl/rooster.html`, `nl/coach.html`, `nl/aanmelden.html`.
- `public/assets/js/` — `choreo.js` (bandShape(p), pose(p): pure functions), `band.js` (procedural model + studio),
  `scene.js` (renderer, mirror, post, quality levels, adaptive DPR, «Pull» cursor), `app.js` (home: preloader, scroll,
  callouts, `?p=` / `?demo=1` / `?pre=1`), `page.js` (inner pages), `common.js` (menu, cursor, «Rek» headings,
  «Curtain call» page transition, footer loop).
- `public/assets/vendor/` — three.js r170 (+ addons), GSAP 3.15 — local, no CDN. Fonts self-hosted (OFL).
- `_notes/build.py` + `_notes/content.py` — all copy (EN + NL) → HTML: `python3 _notes/build.py`.
- `_notes/test-choreo.mjs` — `node _notes/test-choreo.mjs` (reversible, no jumps, no self-intersection, final in frame).
- `_notes/check.py`, `shoot.py`, `fps.py`, `stills.py` — QA in Chrome (Playwright), screenshots → `_notes/review1/`.

## Publish
```bash
npx wrangler login      # once
npx wrangler deploy     # from this folder
```
Local: `python3 -m http.server -d public 8080`. Dev params on the home page: `?p=0.5` (still frame), `?demo=1`
(fixed 46 s run for video, `window.__demo`), `?pre=1` (always show preloader), `?q=0..2` (fixed quality).

## Registration
`/register` builds the message (name, which Monday, experience, note) and opens `wa.me/31616134806` with the text ready.
The site itself sends nothing. All other buttons go straight to WhatsApp / Instagram.

## To confirm with the client (shown neutrally as «on request» on the site)
- Studio address / district in Enschede; price (PRICE highlight); duration and level of the class.
- Exact wording of her «2 simple steps» (site, neutral: 01 Message on WhatsApp, 02 Get a reply).
- Who issued the certificate; coach name (site only says «certified stretching coach» + link to @vsavelyeva).
- Audience language (RU/UA version?); permission for photos of people (site uses none).
